from django.apps import AppConfig


class ChinookConfig(AppConfig):
    name = 'chinook'
