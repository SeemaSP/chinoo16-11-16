// jQuery initalized in base.html
window.jQuery = window.$ = django.jQuery;
